package com.company.hrpayroll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrpayrollApplicationTests {

	@Test
	void contextLoads() {
	}

}
